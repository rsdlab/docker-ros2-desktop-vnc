#!/usr/bin/env python3
# coding: UTF-8
#
# 課題2：ワーク認識サービスサーバ（回答例）
#
# WorkDetectNode.py の TODO-1 〜 TODO-4 を埋めた完成版です。
# 穴あき部分のみコメントで「←TODO-x 回答」と示しています。

import rclpy
from rclpy.node import Node

from std_msgs.msg import Float32
from geometry_msgs.msg import Point

# === TODO-1 回答 ======================================================
# サービス型 DetectWorkpieces とメッセージ型 WorkDetectionResult をインポート.
from collaboration_manipulation_message.srv import DetectWorkpieces
from collaboration_manipulation_message.msg import WorkDetectionResult
# ======================================================================


class WorkDetect(Node):
    def __init__(self):
        super().__init__('work_detection_node')

        # === TODO-2 回答 ==============================================
        # サービスサーバを作成する.
        #   型 DetectWorkpieces / 名 'detect_workpieces_service' / cb pose_request
        self.setup_req = self.create_service(
            DetectWorkpieces, 'detect_workpieces_service', self.pose_request)
        # =============================================================

        print("Initialization done")

    # サービスが呼ばれるたびに実行されるコールバック.
    def pose_request(self, req_, res):
        print("")
        print("Request Data:")
        print(req_)
        print("")

        # === TODO-3 回答 ==============================================
        # ワーク認識結果を1件つくり、要求された work_type_id を入れる.
        set_data = WorkDetectionResult()
        set_data.work_type_id = req_.work_type_id
        # =============================================================

        # === TODO-4 回答 ==============================================
        # 作った結果をレスポンスのリスト（2段ネスト）に追加して返す.
        res.work_detection_results.work_detection_results.append(set_data)
        # =============================================================

        return res


def main():
    rclpy.init()
    wd = WorkDetect()
    rclpy.spin(wd)


if __name__ == "__main__":
    main()
