#!/usr/bin/env python3
# coding: UTF-8
#
# 課題2：ワーク認識サービスサーバ（穴あき演習用）
#
# 人協働マニピュレーションモジュールは、作業の準備段階で
# 「どこにどんなワークがあるか」をワーク認識サブシステムに問い合わせます。
# その問い合わせは ROS2 サービス `detect_workpieces_service`
# （型：collaboration_manipulation_message/srv/DetectWorkpieces）で行われます。
#
# このノードは、その問い合わせに「答える側（サービスサーバ）」です。
# リクエストを受け取り、ワーク認識結果を作って返してください。
#
# TODO-1 〜 TODO-4 を埋めると完成します。
# （本物の画像処理は行わず、リクエスト内容をそのまま結果に詰めて返す簡易版です）

import rclpy
from rclpy.node import Node

# ↓ ベースにした実システムの import（演習でも使います）
from std_msgs.msg import Float32
from geometry_msgs.msg import Point

# === TODO-1 ===========================================================
# サービス型とメッセージ型をインポートしてください。
#   ・サービス型 : collaboration_manipulation_message/srv の DetectWorkpieces
#   ・メッセージ型 : collaboration_manipulation_message/msg の WorkDetectionResult
#
# ヒント：
#   from collaboration_manipulation_message.srv import ____
#   from collaboration_manipulation_message.msg import ____
# ======================================================================
# ここから

# ここまで


class WorkDetect(Node):
    def __init__(self):
        super().__init__('work_detection_node')

        # === TODO-2 ===================================================
        # サービスサーバを作成してください。
        #   ・サービス型   : DetectWorkpieces
        #   ・サービス名   : 'detect_workpieces_service'
        #   ・コールバック : self.pose_request
        #
        # ヒント：
        #   self.setup_req = self.create_service(____, ____, ____)
        # ==============================================================
        # ここから

        # ここまで

        print("Initialization done")

    # サービスが呼ばれるたびに実行されるコールバック.
    # req_ : リクエスト（DetectWorkpieces.Request）
    # res  : レスポンス（DetectWorkpieces.Response）。中身を詰めて return する.
    def pose_request(self, req_, res):
        # リクエストの確認（そのまま表示）.
        print("")
        print("Request Data:")
        print(req_)
        print("")

        # === TODO-3 ===================================================
        # ワーク認識結果を1件つくってください。
        #   ・WorkDetectionResult のインスタンスを作る
        #   ・work_type_id に、リクエストの work_type_id を入れる
        #     （本物では検知したワークの種類を入れるが、ここでは要求された種類を返す）
        #
        # ヒント：
        #   set_data = ____()
        #   set_data.work_type_id = req_.____
        # ==============================================================
        # ここから

        # ここまで

        # === TODO-4 ===================================================
        # 作った結果をレスポンスのリストに追加して返してください。
        # レスポンスの構造（DetectWorkpieces.srv / WorkDetectionResultList.msg より）：
        #   res.work_detection_results                       … リスト(List)を包むメッセージ
        #   res.work_detection_results.work_detection_results … 実際の WorkDetectionResult[] 配列
        #
        # ヒント：append でリストに1件追加する.
        #   res.work_detection_results.work_detection_results.append(____)
        # ==============================================================
        # ここから

        # ここまで

        return res


def main():
    rclpy.init()
    wd = WorkDetect()
    rclpy.spin(wd)


if __name__ == "__main__":
    main()
