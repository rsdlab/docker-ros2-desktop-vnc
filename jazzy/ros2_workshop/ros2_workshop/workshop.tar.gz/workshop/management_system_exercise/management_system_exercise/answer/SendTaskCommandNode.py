#!/usr/bin/env python3
# coding: UTF-8
#
# 課題3：上位アプリから作業を指令する  ＝＝＝ 解答（完成版） ＝＝＝
#
# TODO-1 〜 TODO-4 をすべて埋めたリファレンス解答です。
# （穴あき版は ../SendTaskCommandNode.py）
# 実行：ros2 run management_system_exercise SendTaskCommandAnswer

import rclpy
from rclpy.node import Node

# === TODO-1（解答） ===================================================
from collaboration_manipulation_message.srv import SendTaskCommand
from collaboration_manipulation_message.msg import (
    TaskCommand, TaskCommandList, TargetArea, PlaceAreaCandidatesList,
)
# =====================================================================

# 作業指令の応答（受理されたか）の判定に使う列挙.
from collaboration_manipulation_module.EnumerateModule import EnumCommandReceiveState

PICK_COMMAND = 0  # 作業指令ID：ピック


class TaskCommandSender(Node):
    def __init__(self):
        super().__init__('task_command_sender_node')

        # === TODO-2（解答） ===========================================
        self.cli = self.create_client(SendTaskCommand, 'send_command_service')
        # =============================================================

        # サービス（人協働モジュール側）が立ち上がるまで待つ.
        while not self.cli.wait_for_service(timeout_sec=1.0):
            self.get_logger().warn('send_command_service を待っています...')

        print('Initialization done')

    # 作業指令（ピック）を1件送る.
    def send_pick(self):
        # --- 作業エリア・排出候補は雛形として用意済み（変更不要） ---
        work_area = TargetArea()
        work_area.start_point.x = -2.0
        work_area.start_point.y = -2.0
        work_area.start_point.z = 0.0
        work_area.end_point.x = 2.0
        work_area.end_point.y = 2.0
        work_area.end_point.z = 2.0

        # --- 排出位置候補も雛形として用意済み（変更不要） ---
        # これが空のままだとモジュール側の set_place_area が IndexError になる.
        place_candidates = PlaceAreaCandidatesList()
        dis_area = TargetArea()
        dis_area.start_point.x = -2.0
        dis_area.start_point.y = -2.0
        dis_area.start_point.z = 0.0
        dis_area.end_point.x = 2.0
        dis_area.end_point.y = 2.0
        dis_area.end_point.z = 2.0
        place_candidates.place_area_candidates.append(dis_area)

        # === TODO-3（解答） ===========================================
        # 1) 作業指令を作る.
        cmd = TaskCommand()
        cmd.task_command_id = PICK_COMMAND
        cmd.work_type_id = 1
        cmd.picking_count = 1
        cmd.work_presence_area = work_area
        cmd.place_area_candidates = place_candidates

        # 2) 作業指令リストに詰める.
        cmd_list = TaskCommandList()
        cmd_list.task_commands.append(cmd)

        # 3) リクエストに詰める.
        req = SendTaskCommand.Request()
        req.task_commands = cmd_list
        # =============================================================

        # === TODO-4（解答） ===========================================
        future = self.cli.call_async(req)
        rclpy.spin_until_future_complete(self, future)
        result = future.result()

        print('作業指令応答:', result.response)
        if result.response == EnumCommandReceiveState.e_received():
            print('受理されました（received）')
        else:
            print('受理されませんでした（busy など）')
        # =============================================================


def main():
    rclpy.init()
    node = TaskCommandSender()
    node.send_pick()
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
