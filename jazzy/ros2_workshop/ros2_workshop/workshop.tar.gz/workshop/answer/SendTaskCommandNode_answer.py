#!/usr/bin/env python3
# coding: UTF-8
#
# 課題3：上位アプリから作業を指令する（回答例）
#
# SendTaskCommandNode.py の TODO-1 〜 TODO-4 を埋めた完成版です。
# 穴あき部分のみコメントで「←TODO-x 回答」と示しています。

import rclpy
from rclpy.node import Node

# === TODO-1 回答 ======================================================
# 作業指令に必要なサービス型・メッセージ型をインポート.
from collaboration_manipulation_message.srv import SendTaskCommand
from collaboration_manipulation_message.msg import (
    TaskCommand, TaskCommandList, TargetArea, PlaceAreaCandidatesList)
# ======================================================================

from collaboration_manipulation_module.EnumerateModule import EnumCommandReceiveState

PICK_COMMAND = 0  # 作業指令ID：ピック


class TaskCommandSender(Node):
    def __init__(self):
        super().__init__('task_command_sender_node')

        # === TODO-2 回答 ==========================================
        # 作業指令サービスのクライアントを作成する.
        self.cli = self.create_client(SendTaskCommand, 'send_command_service')
        # =========================================================

        while not self.cli.wait_for_service(timeout_sec=1.0):
            self.get_logger().warn('send_command_service を待っています...')

        print('Initialization done')

    # 作業指令（ピック）を1件送る.
    def send_pick(self):
        # --- 作業エリア（変更不要） ---
        work_area = TargetArea()
        work_area.start_point.x = -2.0
        work_area.start_point.y = -2.0
        work_area.start_point.z = 0.0
        work_area.end_point.x = 2.0
        work_area.end_point.y = 2.0
        work_area.end_point.z = 2.0

        # --- 排出位置候補（変更不要） ---
        place_candidates = PlaceAreaCandidatesList()
        dis_area = TargetArea()
        dis_area.start_point.x = -2.0
        dis_area.start_point.y = -2.0
        dis_area.start_point.z = 0.0
        dis_area.end_point.x = 2.0
        dis_area.end_point.y = 2.0
        dis_area.end_point.z = 2.0
        place_candidates.place_area_candidates.append(dis_area)

        # === TODO-3 回答 ==========================================
        # 1) 作業指令 TaskCommand を組み立てる.
        cmd = TaskCommand()
        cmd.task_command_id = PICK_COMMAND
        cmd.work_type_id = 1
        cmd.picking_count = 1
        cmd.work_presence_area = work_area
        cmd.place_area_candidates = place_candidates
        # 2) TaskCommandList に詰める.
        cmd_list = TaskCommandList()
        cmd_list.task_commands.append(cmd)
        # 3) リクエストに入れる.
        req = SendTaskCommand.Request()
        req.task_commands = cmd_list
        # =========================================================

        # === TODO-4 回答 ==========================================
        # サービスを非同期で呼び、応答を待って受理されたか確認する.
        future = self.cli.call_async(req)
        rclpy.spin_until_future_complete(self, future)
        result = future.result()
        print('作業指令応答:', result.response)
        if result.response == EnumCommandReceiveState.e_received():
            print('受理されました（received）')
        else:
            print('受理されませんでした（busy など）')
        # =========================================================


def main():
    rclpy.init()
    node = TaskCommandSender()
    node.send_pick()
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
