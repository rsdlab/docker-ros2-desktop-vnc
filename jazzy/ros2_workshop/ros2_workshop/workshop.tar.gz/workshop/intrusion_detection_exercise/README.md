# 課題1：周辺環境・人検出

人協働マニピュレーションモジュールは、作業中常に人検知トピック
`/intrusion_result`（`std_msgs/Int16`）を監視しています。
ここに「人あり（`1`）」を流すと、ロボットは安全のため動作を停止します。

このノードを完成させて、**自分のコードでロボットを止めて**みましょう。

## 前提（先に起動しておくもの）

- **このノード単体で確認できます。** 他のノードの起動は不要です
  （`ros2 run` → 監視エリア設定サービスを叩く → `/intrusion_result` を確認）。
- 本物の周辺環境認識ノード（`peripheral_environment_detection_subsystem`）とは
  同じトピック/サービスを使うため、**同時に起動しないでください**。
- 「人検知でロボットが実際に一時停止／再開する」ところまで見るには、人協働システム一式
  （`CollaborationManipulationModule` ＋ MoveGroup/Gazebo など）を起動し、作業を
  Running にしておく必要があります（発展）。

## 仕様

| 項目 | 値 |
|---|---|
| ノード名 | `peripheral_environment_detection_node` |
| トピック名 | `/intrusion_result` |
| メッセージ型 | `std_msgs/Int16` |
| 値の意味 | `1` = 人あり（停止） / `0` = 人なし |
| ループ周期 | 10 Hz（`mainloop`） |
| publish 条件 | 監視エリア設定サービス（`per_env_det_service`）が呼ばれた後 |

## ベースにした元ファイル

実システムの周辺環境認識ノード
`peripheral_environment_detection_subsystem/.../PerEnvDetectNode.py`
を演習版にしたものです。**人検知結果を publish する部分だけ**を穴あきにしています。
監視エリア設定（サービス）や距離センサ購読など、その他は元ファイルのままです。

> 注意：受信側（人協働モジュールの `MonitorState`）は `Int16` で
> このトピックを購読しています。送る側もそれに合わせて **`Int16`** で実装します。

## やること

`intrusion_detection_exercise/PerEnvDetectNode.py` の
`TODO-1` 〜 `TODO-3` を埋めてください。

1. `TODO-1`：`Int16` 型をインポート
2. `TODO-2`：`/intrusion_result` へのパブリッシャを作成
3. `TODO-3`：`self.result_data` を載せて publish

## ビルドと実行

```bash
# ワークスペース直下で
cd ~/seed_ROS2_ws
colcon build --packages-select intrusion_detection_exercise
source install/setup.bash

# 実行
ros2 run intrusion_detection_exercise PerEnvDetectNode
```

## 動作確認

別ターミナルで、トピックの型と中身を確認：

```bash
ros2 topic info /intrusion_result        # 型が std_msgs/Int16 であること
ros2 topic echo /intrusion_result
```

人協働システムを実際に止めたい場合は、手動でトピックに「人あり」を流します：

```bash
ros2 topic pub /intrusion_result std_msgs/Int16 "{data: 1}"
```

## 完成ライン

- [ ] `/intrusion_result` が `std_msgs/Int16` 型で publish される
- [ ] 値を `1` にするとロボットが停止する
