# 課題3：上位アプリから作業を指令する

簡略シーケンス図の **「上位アプリ → 人協働マニピュレーション：作業指令を伝達する」**
と、その **「作業指令応答」** を担う部分です。

上位アプリ（このノード）は ROS2 **サービス** `send_command_service` を呼んで、
人協働マニピュレーションモジュールに「ピックして」という作業指令を出します。
モジュールは **受理(received) / 取り込み中(busy)** を応答として返します。

## 通信パターンの位置づけ

| 課題 | 役割 | 通信 |
|---|---|---|
| 課題1 | 人検知パブリッシャ | トピックを **publish する** |
| 課題2 | ワーク認識サービス | サービスに **答える（server）** |
| **課題3** | **上位アプリ（作業指令）** | **サービスを呼ぶ（client）** |

## 前提（先に起動しておくもの）

このノードは「サービスを**呼ぶ**側」なので、**相手（人協働モジュール）が起動している必要があります。**

- **最低限（「受理されました」だけ確認する場合）**
  - `CollaborationManipulationModule`（`send_command_service` を提供）
  - ただしモジュールは起動時に初期姿勢を動かすため、**MoveGroup（`move_action`）が無いと
    Standby に到達せず、指令を受理できません**。Gazebo 等のシミュレーション一式が必要です。
- **最後（Pick 動作）まで確認する場合**
  - 上記に加えて、ワーク認識サービス（課題2 or 本物）と排出位置検出サービス（本物）が必要
  - 起動順：**MoveGroup/Gazebo → CollaborationManipulationModule → 検出系 → このノード**
- 本物の上位アプリ（`management_system` の `ManagementSystemNode`）とは同じ
  `send_command_service` を呼ぶため、**同時に使わないでください**。

## 仕様

| 項目 | 値 |
|---|---|
| ノード名 | `task_command_sender_node` |
| サービス名 | `send_command_service` |
| サービス型 | `collaboration_manipulation_message/srv/SendTaskCommand` |
| 役割 | 作業指令（ピック）を1件送り、応答を確認する |

### サービス型の構造（`SendTaskCommand.srv`）

```
# リクエスト
collaboration_manipulation_message/TaskCommandList task_commands
---
# レスポンス
int16 response   # 作業指令応答（received / busy など）
```

`TaskCommandList` は `TaskCommand[] task_commands` を持ちます。
`TaskCommand` の主なフィールド：
```
uint16 task_command_id      # 作業指令ID（ピック=0）
uint16 work_type_id         # ワーク種類ID
uint16 picking_count        # ピッキング個数
TargetArea work_presence_area  # ワークが存在するエリア
...
```

## やること

`management_system_exercise/SendTaskCommandNode.py` の
`TODO-1` 〜 `TODO-4` を埋めてください。

1. `TODO-1`：`SendTaskCommand`(srv) と `TaskCommand`/`TaskCommandList`/`TargetArea`(msg) をインポート
2. `TODO-2`：`send_command_service` のサービスクライアントを作成
3. `TODO-3`：`TaskCommand` を組み立て、`TaskCommandList` 経由でリクエストに詰める
4. `TODO-4`：サービスを呼び、応答（received か）を確認

## ビルドと実行

```bash
cd ~/seed_ROS2_ws
colcon build --packages-select management_system_exercise
source install/setup.bash
```

> 注意：本物の `management_system`（ManagementSystemNode）と**同時に使わない**でください。
> 同じ `send_command_service` を呼ぶため、指令が二重になります。

## 動作確認

### 1. 人協働モジュールを起動

作業指令を受ける相手が必要です。最低限これを起動しておきます：

```bash
ros2 run collaboration_manipulation_module CollaborationManipulationModule --ros-args -p use_sim_time:=true
```
（実際に動かすには、他の検出系ノードや Gazebo も必要です）

### 2. このノードを実行して指令を送る

```bash
ros2 run management_system_exercise SendTaskCommandNode
```

期待結果：
- このノード側に `作業指令応答: 1` → `受理されました（received）` が出る
- 人協働モジュール側に `TaskCommandServer::recv_task_command` が出て、作業が始まる

> 補足：モジュールが **待機(Standby) 以外**のときに送ると `busy` が返ります
> （[CollaborationCommunicationModule.py の recv_task_command 参照]）。
> その場合は作業が終わって Standby に戻ってから送り直してください。

## 完成ライン

- [ ] `SendTaskCommandNode` 実行で `send_command_service` を1回呼べる
- [ ] 応答が `received`（受理）で返る
- [ ] 人協働モジュール側で作業が開始する
