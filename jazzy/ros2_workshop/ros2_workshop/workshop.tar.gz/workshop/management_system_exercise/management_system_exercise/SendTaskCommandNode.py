#!/usr/bin/env python3
# coding: UTF-8
#
# 課題3：上位アプリから作業を指令する（穴あき演習用）
#
# 簡略シーケンス図の「上位アプリ → 人協働マニピュレーション：作業指令を伝達する」
# とその応答（作業指令応答）を担う部分です。
#
# 上位アプリ（このノード）は、ROS2 サービス `send_command_service` を呼んで
# 人協働マニピュレーションモジュールに「ピックして」と作業指令を出します。
# モジュールは「受理(received)／取り込み中(busy)」を応答として返します。
#
# 役割：このノードは「呼ぶ側（サービスクライアント）」です。
#   ・課題1 = トピックを publish する側
#   ・課題2 = サービスに答える側（server）
#   ・課題3 = サービスを呼ぶ側（client）   ← イマココ
#
# TODO-1 〜 TODO-4 を埋めると完成します。

import rclpy
from rclpy.node import Node

# === TODO-1 ===========================================================
# 作業指令に必要な型をインポートしてください。
#   ・サービス型 : collaboration_manipulation_message/srv の SendTaskCommand
#   ・メッセージ型 : collaboration_manipulation_message/msg の
#                    TaskCommand / TaskCommandList / TargetArea / PlaceAreaCandidatesList
#
# ヒント：
#   from collaboration_manipulation_message.srv import ____
#   from collaboration_manipulation_message.msg import ____, ____, ____, ____
# ======================================================================
# ここから

# ここまで

# 作業指令の応答（受理されたか）の判定に使う列挙.
from collaboration_manipulation_module.EnumerateModule import EnumCommandReceiveState

PICK_COMMAND = 0  # 作業指令ID：ピック


class TaskCommandSender(Node):
    def __init__(self):
        super().__init__('task_command_sender_node')

        # === TODO-2 ===============================================
        # 作業指令サービスのクライアントを作成してください。
        #   ・サービス型 : SendTaskCommand
        #   ・サービス名 : 'send_command_service'
        #
        # ヒント：
        #   self.cli = self.create_client(____, ____)
        # ==========================================================
        # ここから

        # ここまで

        # サービス（人協働モジュール側）が立ち上がるまで待つ.
        while not self.cli.wait_for_service(timeout_sec=1.0):
            self.get_logger().warn('send_command_service を待っています...')

        print('Initialization done')

    # 作業指令（ピック）を1件送る.
    def send_pick(self):
        # --- 作業エリア・排出候補は雛形として用意済み（変更不要） ---
        work_area = TargetArea()
        work_area.start_point.x = -2.0
        work_area.start_point.y = -2.0
        work_area.start_point.z = 0.0
        work_area.end_point.x = 2.0
        work_area.end_point.y = 2.0
        work_area.end_point.z = 2.0

        # --- 排出位置候補も雛形として用意済み（変更不要） ---
        # これが空のままだとモジュール側で IndexError になるため、必ず指令に入れる.
        place_candidates = PlaceAreaCandidatesList()
        dis_area = TargetArea()
        dis_area.start_point.x = -2.0
        dis_area.start_point.y = -2.0
        dis_area.start_point.z = 0.0
        dis_area.end_point.x = 2.0
        dis_area.end_point.y = 2.0
        dis_area.end_point.z = 2.0
        place_candidates.place_area_candidates.append(dis_area)

        # === TODO-3 ===============================================
        # 作業指令（TaskCommand）を組み立て、リクエストに詰めてください。
        #   1) TaskCommand を作り、次を設定する
        #        ・task_command_id  = PICK_COMMAND
        #        ・work_type_id     = 1
        #        ・picking_count    = 1
        #        ・work_presence_area  = work_area（上の雛形）
        #        ・place_area_candidates = place_candidates（上の雛形）
        #   2) TaskCommandList を作り、その task_commands に 1) を append する
        #   3) SendTaskCommand.Request を作り、task_commands に 2) を入れる
        #
        # ヒント：
        #   cmd = TaskCommand()
        #   cmd.task_command_id = ____
        #   cmd.work_type_id    = ____
        #   cmd.picking_count   = ____
        #   cmd.work_presence_area = ____
        #   cmd.place_area_candidates = ____
        #   cmd_list = TaskCommandList()
        #   cmd_list.task_commands.append(____)
        #   req = SendTaskCommand.Request()
        #   req.task_commands = ____
        # ==========================================================
        # ここから

        # ここまで

        # === TODO-4 ===============================================
        # サービスを非同期で呼び出し、応答が返るまで待って結果を確認してください。
        #   ・self.cli.call_async(req) で呼ぶ
        #   ・rclpy.spin_until_future_complete(self, future) で完了待ち
        #   ・future.result().response を表示し、受理されたか判定する
        #     （受理 = EnumCommandReceiveState.e_received()）
        #
        # ヒント：
        #   future = self.cli.call_async(____)
        #   rclpy.spin_until_future_complete(self, ____)
        #   result = future.result()
        #   print('作業指令応答:', result.response)
        #   if result.response == EnumCommandReceiveState.e_received():
        #       print('受理されました（received）')
        #   else:
        #       print('受理されませんでした（busy など）')
        # ==========================================================
        # ここから

        # ここまで


def main():
    rclpy.init()
    node = TaskCommandSender()
    node.send_pick()
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
