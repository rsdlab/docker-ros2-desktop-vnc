# 課題2：ワーク認識サービスサーバ

人協働マニピュレーションモジュールは、作業の**準備段階（Preparing）**で
「対象エリアにどんなワークがあるか」をワーク認識サブシステムに問い合わせます。
この問い合わせは ROS2 **サービス** `detect_workpieces_service` で行われます。

- 問い合わせる側（クライアント）＝ 人協働モジュールの `WorkDetectionClient`
- **答える側（サーバ）＝ このノード（あなたが完成させる）**

課題1（人検知パブリッシャ）が「一方的に流す publisher」だったのに対し、
今回は「呼ばれたら答える service server」を実装します。

## 前提（先に起動しておくもの）

- **このノード単体で確認できます。** 他のノードの起動は不要です
  （`ros2 run` → `ros2 service call` で確認）。
- 本物のワーク認識ノード（`workpieces_detection_subsystem` の `WorkpiecesDetectionNode`）とは
  同じサービス名 `detect_workpieces_service` を使うため、**同時に起動しないでください**。

## 仕様

| 項目 | 値 |
|---|---|
| ノード名 | `work_detection_node` |
| サービス名 | `detect_workpieces_service` |
| サービス型 | `collaboration_manipulation_message/srv/DetectWorkpieces` |
| 役割 | リクエストを受け取り、ワーク認識結果リストを返す |

### サービス型の構造（`DetectWorkpieces.srv`）

```
# リクエスト
uint16 task_command_id
uint16 work_type_id
collaboration_manipulation_message/TargetArea target_area
collaboration_manipulation_message/Property[] properties
---
# レスポンス
collaboration_manipulation_message/WorkDetectionResultList work_detection_results
```

`WorkDetectionResultList` は `WorkDetectionResult[] work_detection_results` を持ちます。
つまりレスポンスは **2段階のネスト**になっています：

```
res.work_detection_results.work_detection_results  ← ここが WorkDetectionResult の配列
```

## ベースにした元ファイル

実システムのワーク認識ノード
`workpieces_detection_subsystem/.../WorkpiecesDetectionNode.py`
を演習版にしたものです。本物の画像処理は行わず、
**リクエスト内容をそのまま結果に詰めて返す簡易版**にしています。
サービスサーバの作り方・レスポンスの組み立て方を学ぶのが目的です。

## やること

`workpieces_detection_exercise/WorkDetectNode.py` の
`TODO-1` 〜 `TODO-4` を埋めてください。

1. `TODO-1`：`DetectWorkpieces`（srv）と `WorkDetectionResult`（msg）をインポート
2. `TODO-2`：`detect_workpieces_service` サービスサーバを作成
3. `TODO-3`：`WorkDetectionResult` を1件つくり `work_type_id` を設定
4. `TODO-4`：レスポンスのリストに `append` して返す

## ビルドと実行

```bash
# ワークスペース直下で
cd ~/seed_ROS2_ws
colcon build --packages-select workpieces_detection_exercise
source install/setup.bash

# 実行
ros2 run workpieces_detection_exercise WorkDetectNode
```

> 注意：本物の `workpieces_detection_subsystem` も同じサービス名
> `detect_workpieces_service` を使います。両方を同時に起動しないでください
> （サービス名が衝突します）。演習中は本物の方を止めておきます。

## 動作確認

### 1. サービスが立っているか確認

別ターミナルで：

```bash
ros2 service list | grep detect_workpieces_service
ros2 service type /detect_workpieces_service
# → collaboration_manipulation_message/srv/DetectWorkpieces と出ればOK
```

### 2. 単体でサービスを呼んでみる

```bash
ros2 service call /detect_workpieces_service \
  collaboration_manipulation_message/srv/DetectWorkpieces \
  "{task_command_id: 1, work_type_id: 5}"
```

レスポンスに `work_type_id: 5` を含む結果が1件返ってくれば成功です。

## 完成ライン

- [ ] `detect_workpieces_service` が `DetectWorkpieces` 型で立ち上がる
- [ ] `ros2 service call` でリクエストを送ると結果リストが1件返る
- [ ] 返ってきた結果の `work_type_id` がリクエストと一致している
