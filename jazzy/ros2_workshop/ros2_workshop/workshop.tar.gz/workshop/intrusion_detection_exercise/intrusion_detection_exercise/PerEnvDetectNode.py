#!/usr/bin/env python3
# coding: UTF-8
#
# 課題1：人検知パブリッシャ（穴あき演習用）
#
# 人協働マニピュレーションモジュールは、作業中つねに人検知トピック
# `/intrusion_result`（std_msgs/Int16）を監視しています。
# ここに「人あり（1）」を流すと、ロボットは安全のため動作を停止します。
#
# このノードは周辺環境認識ノードの演習版です。
# 「人検知結果を publish する部分」だけを穴あきにしています。
# 監視エリア設定（サービス）や距離センサ購読などは本物のままです。
#
# TODO-1 〜 TODO-3 を埋めると完成します。

import rclpy
import time
import threading

# === TODO-1 ===========================================================
# 人検知結果を送るためのメッセージ型 Int16 をインポートしてください。
# Float32 は距離センサ購読で使うので、すでに import 済みです。
#
# ヒント： from std_msgs.msg import Float32, ____
# ======================================================================
from std_msgs.msg import Float32  # ←この行に Int16 を追加する

from geometry_msgs.msg import Point
from collaboration_manipulation_message.srv import SetMonitoringArea
from collaboration_manipulation_message.msg import MonitoringAreaList
from rclpy.node import Node


class AreaIntrusionDetect(Node):
    def __init__(self):
        super().__init__("peripheral_environment_detection_node")

        # === TODO-2 ===================================================
        # 人検知結果を流すパブリッシャを作成してください。
        #   ・メッセージ型 : Int16
        #   ・トピック名   : '/intrusion_result'
        #   ・キューサイズ : 10
        #
        # ヒント：
        #   self.result_pub = self.create_publisher(____, ____, ____)
        # ==============================================================
        # ここから

        # ここまで

        self.length_sub = self.create_subscription(Float32, '/len_topic', self.UrgCallback, 10)
        self.setup_req = self.create_service(SetMonitoringArea, 'per_env_det_service', self.setup_request)
        self.setup_data = MonitoringAreaList()
        self.result_data = 0   # 0 = 人なし / 1 = 人あり（停止）
        self.urg_data = Float32()
        self.basis_length = 0.3  # [m]

        print("Initialization done")

    # 監視エリア設定サービス（本物のまま）.
    def setup_request(self, req_, res):
        self.setup_data.monitoring_areas = req_.monitoring_areas
        if self.setup_data.monitoring_areas:
            print("Setup succeeded")
            res.response = 1
            print("Setup Data")
            print(self.setup_data)
            print("AreaIntrusionDetection start!")
        else:
            print("Setup fail")
            res.response = 0
        return res

    # 距離センサ購読（本物のまま）.
    def UrgCallback(self, urg_):
        self.urg_data = urg_.data

    def mainloop(self):
        rate_hz = 10.0
        period = 1.0 / rate_hz
        while rclpy.ok():
            # 監視エリアが設定されている間だけ publish する.
            if self.setup_data.monitoring_areas:

                # === TODO-3 ===========================================
                # Int16 メッセージを作り、self.result_data を載せて
                # /intrusion_result へ publish してください。
                #
                # ヒント：
                #   msg = Int16()
                #   msg.data = self.____
                #   self.result_pub.publish(____)
                # ======================================================
                # ここから

                # ここまで

                self.setup_data = MonitoringAreaList()

            time.sleep(period)


def main():
    rclpy.init()
    aid = AreaIntrusionDetect()

    # mainloop（publish処理）は別スレッドで回しつつ、本体は rclpy.spin で
    # サービス（per_env_det_service）や購読のコールバックを処理する.
    # これをしないとサービスが応答せず、publish のきっかけ（監視エリア設定）が
    # 永久に来ないため、ノードは何も publish できない.
    loop_thread = threading.Thread(target=aid.mainloop, daemon=True)
    loop_thread.start()

    try:
        rclpy.spin(aid)
    except KeyboardInterrupt:
        pass
    finally:
        aid.destroy_node()
        rclpy.shutdown()


if __name__ == "__main__":
    main()
