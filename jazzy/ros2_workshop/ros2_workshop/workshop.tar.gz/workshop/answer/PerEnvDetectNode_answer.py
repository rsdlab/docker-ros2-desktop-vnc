#!/usr/bin/env python3
# coding: UTF-8
#
# 課題1：人検知パブリッシャ（回答例）
#
# PerEnvDetectNode.py の TODO-1 〜 TODO-3 を埋めた完成版です。
# 穴あき部分のみコメントで「←TODO-x 回答」と示しています。

import rclpy
import time
import threading

# === TODO-1 回答 ======================================================
# 人検知結果用のメッセージ型 Int16 を追加でインポートする.
from std_msgs.msg import Float32, Int16
# ======================================================================

from geometry_msgs.msg import Point
from collaboration_manipulation_message.srv import SetMonitoringArea
from collaboration_manipulation_message.msg import MonitoringAreaList
from rclpy.node import Node


class AreaIntrusionDetect(Node):
    def __init__(self):
        super().__init__("peripheral_environment_detection_node")

        # === TODO-2 回答 ==============================================
        # 人検知結果を流すパブリッシャを作成する.
        #   型 Int16 / トピック '/intrusion_result' / キュー 10
        self.result_pub = self.create_publisher(Int16, '/intrusion_result', 10)
        # =============================================================

        self.length_sub = self.create_subscription(Float32, '/len_topic', self.UrgCallback, 10)
        self.setup_req = self.create_service(SetMonitoringArea, 'per_env_det_service', self.setup_request)
        self.setup_data = MonitoringAreaList()
        self.result_data = 0   # 0 = 人なし / 1 = 人あり（停止）
        self.urg_data = Float32()
        self.basis_length = 0.3  # [m]

        print("Initialization done")

    # 監視エリア設定サービス（本物のまま）.
    def setup_request(self, req_, res):
        self.setup_data.monitoring_areas = req_.monitoring_areas
        if self.setup_data.monitoring_areas:
            print("Setup succeeded")
            res.response = 1
            print("Setup Data")
            print(self.setup_data)
            print("AreaIntrusionDetection start!")
        else:
            print("Setup fail")
            res.response = 0
        return res

    # 距離センサ購読（本物のまま）.
    def UrgCallback(self, urg_):
        self.urg_data = urg_.data

    def mainloop(self):
        rate_hz = 10.0
        period = 1.0 / rate_hz
        while rclpy.ok():
            # 監視エリアが設定されている間だけ publish する.
            if self.setup_data.monitoring_areas:

                # === TODO-3 回答 ======================================
                # Int16 メッセージを作り、result_data を載せて publish する.
                msg = Int16()
                msg.data = self.result_data
                self.result_pub.publish(msg)
                # =====================================================

                self.setup_data = MonitoringAreaList()

            time.sleep(period)


def main():
    rclpy.init()
    aid = AreaIntrusionDetect()

    loop_thread = threading.Thread(target=aid.mainloop, daemon=True)
    loop_thread.start()

    try:
        rclpy.spin(aid)
    except KeyboardInterrupt:
        pass
    finally:
        aid.destroy_node()
        rclpy.shutdown()


if __name__ == "__main__":
    main()
