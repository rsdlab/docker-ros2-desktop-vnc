from setuptools import find_packages, setup

package_name = 'intrusion_detection_exercise'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='rsdlab',
    maintainer_email='rsdlab@todo.todo',
    description='課題1：人検知パブリッシャ（穴あき演習用）',
    license='MIT',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'PerEnvDetectNode = intrusion_detection_exercise.PerEnvDetectNode:main',
        ],
    },
)
